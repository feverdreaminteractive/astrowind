#include <metal_stdlib>
using namespace metal;

struct VertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex VertexOut vertexShader(uint vertexID [[vertex_id]]) {
    float2 positions[4] = {
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
        float2(-1.0,  1.0),
        float2( 1.0,  1.0)
    };
    VertexOut out;
    out.position = float4(positions[vertexID], 0.0, 1.0);
    out.uv = positions[vertexID];
    return out;
}

struct Uniforms {
    float time;
    float2 resolution;
    float2 mouse;          // horizontal/vertical audio magnitude, each ~0...1
    float colorMagnitude;  // overall loudness, ~0...1
};

// GLSL's mod() is floored (result has the sign of the divisor); Metal's
// fmod() is truncated (result has the sign of the dividend) — several of
// these ported shaders rely on the floored version, so define it explicitly
// rather than risk a silent behavior mismatch from fmod().
float gmod(float x, float y) {
    return x - y * floor(x / y);
}

// Shared across products: tints an otherwise grayscale/limited-palette
// pattern toward a hue-cycling color as loudness (colorMagnitude) rises,
// matching Fever Dream Screen's original moiré shader convention.
float3 hsv2rgb(float3 c) {
    float4 k = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    float3 p = abs(fract(c.xxx + k.xyz) * 6.0 - k.www);
    return c.z * mix(k.xxx, clamp(p - k.xxx, 0.0, 1.0), c.y);
}
// Ported from ~/Downloads/aim/PsychCir2.qtz's second embedded GLSL shader
// (its first is a duplicate of spiral.qtz, skipped — see the spiral
// product). GLSL's normalize() accepts a scalar (returns its sign); Metal's
// normalize() is vector-only, so scalar normalize() calls become sign().
// Bass (mouse.x) warps the origin, treble (mouse.y) speeds the whole thing,
// loudness (colorMagnitude) blends in an extra hue layer on top of the
// original's own Hue()-driven flicker.
float3 hueBloom(float hue) {
    float3 rgb = fract(hue + float3(0.0, 2.0 / 3.0, 1.0 / 3.0));
    rgb = abs(rgb * 2.0 - 1.0);
    return clamp(rgb * 3.0 - 1.0, 0.0, 1.0);
}

fragment float4 fragmentShader(VertexOut in [[stage_in]],
                                constant Uniforms &u [[buffer(0)]]) {
    float2 fragCoord = float2((in.uv.x * 0.5 + 0.5) * u.resolution.x,
                               (in.uv.y * 0.5 + 0.5) * u.resolution.y);

    float2 p = (fragCoord * 2.0 - u.resolution) / min(u.resolution.x, u.resolution.y);
    float t = u.time * (1.0 + u.mouse.y * 0.5);

    float2 warp = float2(p.x + sin(t) + u.mouse.x * 0.3, p.y + sin(t * 0.25));
    float len = length(warp);

    float3 destColor = float3(0.0);
    destColor += sign(sin(0.1 / len * 1.0 + t * 10.0));
    destColor *= hueBloom(sin(t)) * float3(abs(sin(t * 50.0)));

    destColor += sign(sin(0.1 / len * 125.0 + t * 10.0));
    destColor += sign(sin(0.01 / len * 125.0 + t * 10.0));
    destColor -= (0.25 / len);

    destColor *= hueBloom(sin(t)) * float3(abs(sin(t * 25.0)));

    float3 hueOverlay = hsv2rgb(float3(fract(u.time * 0.05 + u.colorMagnitude * 0.6), 0.85, 1.0));
    destColor = mix(destColor, destColor * hueOverlay * 2.0, clamp(u.colorMagnitude, 0.0, 1.0) * 0.5);

    float scanline = gmod(fragCoord.y, 2.0);
    return float4(destColor * scanline * 0.5, 1.0);
}
