#include <metal_stdlib>
using namespace metal;

struct VertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex VertexOut vertexShader(uint vertexID [[vertex_id]]) {
    float2 positions[4] = {
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
        float2(-1.0,  1.0),
        float2( 1.0,  1.0)
    };
    VertexOut out;
    out.position = float4(positions[vertexID], 0.0, 1.0);
    out.uv = positions[vertexID];
    return out;
}

struct Uniforms {
    float time;
    float2 resolution;
    float2 mouse;          // horizontal/vertical audio magnitude, each ~0...1
    float colorMagnitude;  // overall loudness, ~0...1
};

// GLSL's mod() is floored (result has the sign of the divisor); Metal's
// fmod() is truncated (result has the sign of the dividend) — several of
// these ported shaders rely on the floored version, so define it explicitly
// rather than risk a silent behavior mismatch from fmod().
float gmod(float x, float y) {
    return x - y * floor(x / y);
}

// Shared across products: tints an otherwise grayscale/limited-palette
// pattern toward a hue-cycling color as loudness (colorMagnitude) rises,
// matching Fever Dream Screen's original moiré shader convention.
float3 hsv2rgb(float3 c) {
    float4 k = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    float3 p = abs(fract(c.xxx + k.xyz) * 6.0 - k.www);
    return c.z * mix(k.xxx, clamp(p - k.xxx, 0.0, 1.0), c.y);
}
// Ported from ~/Downloads/aim/OpArtSeries1-8.qtz's embedded GLSL. The
// original's A/B/C/D uniforms were unconnected QC input ports (all static
// 0.0 in the patch), so the pattern's only motion there was `time`; here
// they're driven by mouse (bass/treble) and colorMagnitude instead so the
// concentric warp responds a little rather than tracing an identical path
// every cycle. The `hsv()` helper is the patch's own non-standard formula
// (not the shared header's hsv2rgb), kept as-is for visual fidelity.
float3 hsvOpArt(float h, float s, float v) {
    float3 t = clamp(abs(fract(h + float3(3.0, 2.0, 1.0) / 3.0) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return mix(float3(1.0), t, s) * v;
}

fragment float4 fragmentShader(VertexOut in [[stage_in]],
                                constant Uniforms &u [[buffer(0)]]) {
    float2 fragCoord = float2((in.uv.x * 0.5 + 0.5) * u.resolution.x,
                               (in.uv.y * 0.5 + 0.5) * u.resolution.y);

    float2 uv = 2.0 * fragCoord / u.resolution - 1.0;

    float A = u.mouse.x * 6.28318530718;
    float B = u.mouse.y * 6.28318530718;
    float C = u.colorMagnitude * 6.28318530718;
    float D = 0.0;

    uv *= 1.0 - length(uv);
    uv *= sin(abs(cos(uv.x * 6.0 + A) + sin(u.time + uv.y * 6.0 + B)));
    uv += cos(uv.x * 16.0 + C) * sin(u.time + uv.y * 16.0 + D);

    float r = length(uv);

    float3 destColor = (float3(1.0) - float3(exp(r) - 1.1)) * hsvOpArt(0.4 + r * 4.0, 1.0, 1.0);
    return float4(destColor, 1.0);
}
