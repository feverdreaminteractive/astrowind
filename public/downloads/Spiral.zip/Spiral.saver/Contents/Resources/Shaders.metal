#include <metal_stdlib>
using namespace metal;

struct VertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex VertexOut vertexShader(uint vertexID [[vertex_id]]) {
    float2 positions[4] = {
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
        float2(-1.0,  1.0),
        float2( 1.0,  1.0)
    };
    VertexOut out;
    out.position = float4(positions[vertexID], 0.0, 1.0);
    out.uv = positions[vertexID];
    return out;
}

struct Uniforms {
    float time;
    float2 resolution;
    float2 mouse;          // horizontal/vertical audio magnitude, each ~0...1
    float colorMagnitude;  // overall loudness, ~0...1
};

// GLSL's mod() is floored (result has the sign of the divisor); Metal's
// fmod() is truncated (result has the sign of the dividend) — several of
// these ported shaders rely on the floored version, so define it explicitly
// rather than risk a silent behavior mismatch from fmod().
float gmod(float x, float y) {
    return x - y * floor(x / y);
}

// Shared across products: tints an otherwise grayscale/limited-palette
// pattern toward a hue-cycling color as loudness (colorMagnitude) rises,
// matching Fever Dream Screen's original moiré shader convention.
float3 hsv2rgb(float3 c) {
    float4 k = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    float3 p = abs(fract(c.xxx + k.xyz) * 6.0 - k.www);
    return c.z * mix(k.xxx, clamp(p - k.xxx, 0.0, 1.0), c.y);
}
// Ported from ~/Downloads/aim/spiral.qtz's embedded GLSL (identical to
// PsychCir2.qtz's first shader — that one's skipped as a duplicate). Bass
// (mouse.x) rotates the spiral phase, treble (mouse.y) speeds it up.
fragment float4 fragmentShader(VertexOut in [[stage_in]],
                                constant Uniforms &u [[buffer(0)]]) {
    float2 fragCoord = float2((in.uv.x * 0.5 + 0.5) * u.resolution.x,
                               (in.uv.y * 0.5 + 0.5) * u.resolution.y);

    float2 position = (2.0 * fragCoord - u.resolution) / u.resolution.x;

    float r = length(position);
    float a = atan2(position.y, position.x) + u.mouse.x * 3.14159265;

    float3 baseColor = float3(3.0, 0.0, 1.0);
    float t = 0.5 * (1.0 + cos(a + 40.0 * r * (1.0 + sin(a * 20.0) * 0.1) - u.time * (3.0 + u.mouse.y * 2.0)) * (5.0 / (r + 7.5)));
    t = t < 0.8 ? 0.0 : 1.0;

    float3 gray = baseColor * t;
    float3 hueColor = hsv2rgb(float3(fract(u.time * 0.05 + u.colorMagnitude * 0.6), 0.85, t));
    float3 color = mix(gray, hueColor, clamp(u.colorMagnitude, 0.0, 1.0));

    return float4(color, 1.0);
}
