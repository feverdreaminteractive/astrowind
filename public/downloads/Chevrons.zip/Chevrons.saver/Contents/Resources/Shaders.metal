#include <metal_stdlib>
using namespace metal;

struct VertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex VertexOut vertexShader(uint vertexID [[vertex_id]]) {
    float2 positions[4] = {
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
        float2(-1.0,  1.0),
        float2( 1.0,  1.0)
    };
    VertexOut out;
    out.position = float4(positions[vertexID], 0.0, 1.0);
    out.uv = positions[vertexID];
    return out;
}

struct Uniforms {
    float time;
    float2 resolution;
    float2 mouse;          // horizontal/vertical audio magnitude, each ~0...1
    float colorMagnitude;  // overall loudness, ~0...1
};

// GLSL's mod() is floored (result has the sign of the divisor); Metal's
// fmod() is truncated (result has the sign of the dividend) — several of
// these ported shaders rely on the floored version, so define it explicitly
// rather than risk a silent behavior mismatch from fmod().
float gmod(float x, float y) {
    return x - y * floor(x / y);
}

// Shared across products: tints an otherwise grayscale/limited-palette
// pattern toward a hue-cycling color as loudness (colorMagnitude) rises,
// matching Fever Dream Screen's original moiré shader convention.
float3 hsv2rgb(float3 c) {
    float4 k = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    float3 p = abs(fract(c.xxx + k.xyz) * 6.0 - k.www);
    return c.z * mix(k.xxx, clamp(p - k.xxx, 0.0, 1.0), c.y);
}
// Ported from ~/Downloads/aim/chevrons.qtz's embedded GLSL. The original
// had a commented-out cursor-rotation stub — revived here, driven by bass
// (mouse.x) instead of the cursor; treble (mouse.y) speeds the sweep.
fragment float4 fragmentShader(VertexOut in [[stage_in]],
                                constant Uniforms &u [[buffer(0)]]) {
    float2 fragCoord = float2((in.uv.x * 0.5 + 0.5) * u.resolution.x,
                               (in.uv.y * 0.5 + 0.5) * u.resolution.y);

    float3 orange = float3(4.0, 1.5, 0.0);
    float3 pink = float3(4.0, 0.4, 2.2);
    float3 color = orange;
    float width = 200.0;

    float x = fragCoord.x - u.resolution.x / 2.5;
    float y = fragCoord.y - u.resolution.y / 2.5;

    float rotAngle = u.mouse.x * 2.0 * 3.14159265;
    float xr = x * cos(rotAngle) - y * sin(rotAngle);
    float yr = x * sin(rotAngle) + y * cos(rotAngle);

    float s = yr < 0.0 ? 1.0 : -1.0;
    float angle = 3.14159265 / 4.0;
    float xp = xr * cos(angle * s) - yr * sin(angle * s) - u.time * (550.0 + u.mouse.y * 300.0);

    if (gmod(xp, width) - width / 2.0 > 0.0) {
        color = pink;
    }

    return float4(color * 0.5, 1.0);
}
