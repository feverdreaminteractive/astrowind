#include <metal_stdlib>
using namespace metal;

struct VertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex VertexOut vertexShader(uint vertexID [[vertex_id]]) {
    float2 positions[4] = {
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
        float2(-1.0,  1.0),
        float2( 1.0,  1.0)
    };
    VertexOut out;
    out.position = float4(positions[vertexID], 0.0, 1.0);
    out.uv = positions[vertexID];
    return out;
}

struct Uniforms {
    float time;
    float2 resolution;
    float2 mouse;          // horizontal/vertical audio magnitude, each ~0...1
    float colorMagnitude;  // overall loudness, ~0...1
};

// GLSL's mod() is floored (result has the sign of the divisor); Metal's
// fmod() is truncated (result has the sign of the dividend) — several of
// these ported shaders rely on the floored version, so define it explicitly
// rather than risk a silent behavior mismatch from fmod().
float gmod(float x, float y) {
    return x - y * floor(x / y);
}

// Shared across products: tints an otherwise grayscale/limited-palette
// pattern toward a hue-cycling color as loudness (colorMagnitude) rises,
// matching Fever Dream Screen's original moiré shader convention.
float3 hsv2rgb(float3 c) {
    float4 k = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    float3 p = abs(fract(c.xxx + k.xyz) * 6.0 - k.www);
    return c.z * mix(k.xxx, clamp(p - k.xxx, 0.0, 1.0), c.y);
}
// Ported from ~/Downloads/aim/viz28.qtz's embedded GLSL: 100 rounds of
// randomly-chosen horizontal/vertical coordinate folding around a random
// split point, thresholded into flat color bands. The branch taken each
// round is the same for every pixel in a frame (it only depends on the
// loop index and `time`, not per-pixel state) — only the fold's per-pixel
// running position (`a`) and its comparison count (`b`) vary, which is
// what gives the recursive-shatter look. Bass (mouse.x) nudges the split
// points; treble (mouse.y) speeds the pattern's per-frame churn.
float randShatter(float co, float t) {
    return fract(sin(co * 91.6458) * 44423.5453 + fract(t * 0.2452));
}

float sliceShatter(float x, float at) {
    if (x > at) {
        return (x - at) / (1.0 - at);
    }
    return x / at;
}

fragment float4 fragmentShader(VertexOut in [[stage_in]],
                                constant Uniforms &u [[buffer(0)]]) {
    float2 fragCoord = float2((in.uv.x * 0.5 + 0.5) * u.resolution.x,
                               (in.uv.y * 0.5 + 0.5) * u.resolution.y);
    float2 uv = fragCoord / u.resolution;

    float t = u.time * (1.0 + u.mouse.y * 0.5);
    float2 a = uv;
    float b = 0.0;
    for (float i = 0.0; i < 100.0; i += 1.0) {
        float c = clamp(randShatter(i + b + 0.24, t) + u.mouse.x * 0.05, 0.001, 0.999);
        if (randShatter(i + 1.42, t) > 0.5) {
            a = float2(a.x, sliceShatter(a.y, c));
        } else {
            a = float2(sliceShatter(a.x, c), a.y);
        }
        b += (uv.x > c || uv.y > c) ? 1.0 : 0.0;
    }

    float3 color = float3(a.x > 0.825 ? 1.0 : 0.0,
                           a.x < 0.25 ? 1.0 : 0.0,
                           a.x > 0.6 ? 1.0 : 0.0);
    return float4(color, 1.0);
}
